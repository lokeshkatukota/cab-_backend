package com.cabbooking.exceptions;

public class AdminNotFoundException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;
	String msg;

	public AdminNotFoundException(String msg) {
		this.msg = msg;
	}

	@Override
	public String getMessage() {
		return msg;
	}

}
