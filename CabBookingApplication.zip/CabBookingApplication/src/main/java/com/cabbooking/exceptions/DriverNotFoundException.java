package com.cabbooking.exceptions;

public class DriverNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	String msg;

	public DriverNotFoundException(String msg) {
		this.msg = msg;
	}

	@Override
	public String getMessage() {
		return msg;
	}

}
