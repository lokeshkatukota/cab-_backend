package com.cabbooking.exceptions;

public class CabNotFoundException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;
	String msg;

	public CabNotFoundException(String msg) {
		this.msg = msg;
	}

	@Override
	public String getMessage() {
		return msg;
	}

}
