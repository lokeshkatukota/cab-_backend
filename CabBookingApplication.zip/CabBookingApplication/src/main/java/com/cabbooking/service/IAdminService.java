package com.cabbooking.service;

import java.util.List;
import com.cabbooking.entities.AdminEntity;

public interface IAdminService {
	
	public AdminEntity insertAdmin(AdminEntity admin);

	public AdminEntity updateAdmin(AdminEntity admin);

	public boolean deleteAdmin(int adminId);

	public List<AdminEntity> viewAdmins();

}
