package com.cabbooking.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.cabbooking.entities.AdminEntity;
import com.cabbooking.entities.UserEntity;
import com.cabbooking.exceptions.AdminNotFoundException;
import com.cabbooking.jpadao.IAdminJpaDao;
import com.cabbooking.jpadao.IUserJpaDao;

@Service
public class AdminServiceImpl implements IAdminService {

	@Autowired
	private PasswordEncoder bcryptEncoder;
	
	@Autowired
	IAdminJpaDao adminJpaDao;

	@Autowired
	IUserJpaDao userJpaDao;

	UserEntity userEntity = new UserEntity();

	public AdminServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public AdminEntity insertAdmin(AdminEntity adminEntity) {
		adminEntity.getUserId().setPassword(bcryptEncoder.encode(adminEntity.getUserId().getPassword()));
		adminEntity = adminJpaDao.save(adminEntity);
		return adminEntity;
	}

	@Override
	public AdminEntity updateAdmin(AdminEntity adminEntity) {

		adminEntity = adminJpaDao.save(adminEntity);
		return adminEntity;
	}

	@Override
	public boolean deleteAdmin(int adminId) {

		adminJpaDao.deleteById(adminId);
		return true;
	}

	@Override
	public List<AdminEntity> viewAdmins() {

		List<AdminEntity> adminEntityList = adminJpaDao.findAll();
		if (adminEntityList.isEmpty()) {
			throw new AdminNotFoundException("No admins found!!");
		}
		return adminEntityList;
	}

}
