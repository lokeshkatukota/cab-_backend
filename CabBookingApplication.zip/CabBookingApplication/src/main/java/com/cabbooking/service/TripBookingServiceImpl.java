package com.cabbooking.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cabbooking.entities.TripBookingEntity;
import com.cabbooking.jpadao.ITripBookingJpaDao;

@Service
public class TripBookingServiceImpl implements ITripBookingService {

	@Autowired
	ITripBookingJpaDao tripBookingJpaDao;

	public TripBookingServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public TripBookingEntity insertTripBooking(TripBookingEntity tripBookingEntity) {

		return tripBookingJpaDao.save(tripBookingEntity);
	}

	@Override
	public TripBookingEntity updateTripBooking(TripBookingEntity tripBookingEntity) {

		return tripBookingJpaDao.save(tripBookingEntity);
	}

	@Override
	public boolean deleteTripBooking(int tripBookingId) {

		tripBookingJpaDao.deleteById(tripBookingId);
		return true;
	}

	@Override
	public List<TripBookingEntity> viewAllTripBooking() {
		List<TripBookingEntity> tripList = tripBookingJpaDao.findAll();
		return tripList;
	}

	@Override
	public List<TripBookingEntity> getTripsDatewise(LocalDateTime fromDateTime) {

		List<TripBookingEntity> entityList = tripBookingJpaDao.findAllTripsByDate(fromDateTime);

		return entityList;

	}

	@Override
	public List<TripBookingEntity> getCustomerTrips(int customerId) {
		// TODO Auto-generated method stub
		return tripBookingJpaDao.getCustomerTrips(customerId);
	}

	@Override
	public List<TripBookingEntity> getDriverTrips(int driverId) {
		// TODO Auto-generated method stub
		return tripBookingJpaDao.getDriverTrips(driverId);
	}

}
