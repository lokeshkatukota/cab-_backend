package com.cabbooking.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cabbooking.entities.CustomerEntity;
import com.cabbooking.entities.DriverEntity;
import com.cabbooking.exceptions.CustomerNotFoundException;
import com.cabbooking.exceptions.DriverNotFoundException;
import com.cabbooking.jpadao.IDriverJpaDao;

@Service
public class DriverServiceImpl implements IDriverService {

	@Autowired
	private PasswordEncoder bcryptEncoder;
	
	@Autowired
	IDriverJpaDao driverJpaDao;

	@Override
	public DriverEntity insertDriver(DriverEntity driverEntity) {
		driverEntity.getUserId().setPassword(bcryptEncoder.encode(driverEntity.getUserId().getPassword()));
		return driverJpaDao.save(driverEntity);
	}

	@Override
	public DriverEntity updateDriver(DriverEntity driverEntity) {
		return driverJpaDao.save(driverEntity);
	}

	@Override
	public List<DriverEntity> deleteDriver(int driverId) {
		driverJpaDao.deleteById(driverId);
		List<DriverEntity> allDrivers = driverJpaDao.findAll();
		if(allDrivers.isEmpty()) {
			throw new DriverNotFoundException("No Drivers Found!!");
		}
		return allDrivers;
	}

	@Override
	public List<DriverEntity> viewBestDrivers() {
		List<DriverEntity> driverList = driverJpaDao.findByRating();
		if (driverList.isEmpty()) {
			throw new DriverNotFoundException("No best drivers found!!");
		}
		return driverList;
	}

	@Override
	public DriverEntity viewDriver(int driverId) {
		Optional<DriverEntity> result = driverJpaDao.findById(driverId);
		if (result.isPresent()) {
			return result.get();
		} else {
			throw new DriverNotFoundException("No driver found!!");

		}
	}

	@Override
	public List<DriverEntity> viewDrivers() {
		List<DriverEntity> driverList = driverJpaDao.findAll();
		if (driverList.isEmpty()) {
			throw new DriverNotFoundException("No drivers found!!");
		}
		return driverList;
	}
	
	@Override
	public DriverEntity fetchalldetails(int userId) {
		// TODO Auto-generated method stub
		return driverJpaDao.fetchalldetails(userId);
	}


}
