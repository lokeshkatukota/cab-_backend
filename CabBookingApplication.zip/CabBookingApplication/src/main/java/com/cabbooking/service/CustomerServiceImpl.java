package com.cabbooking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cabbooking.entities.CustomerEntity;
import com.cabbooking.exceptions.CustomerNotFoundException;
import com.cabbooking.jpadao.ICustomerJpaDao;

@Service
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	private PasswordEncoder bcryptEncoder;
	
	@Autowired
	ICustomerJpaDao customerJpaDao;

	public CustomerServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public CustomerEntity insertCustomer(CustomerEntity customer) {
        customer.getUserId().setPassword(bcryptEncoder.encode(customer.getUserId().getPassword()));
		return customerJpaDao.save(customer);
	}

	@Override
	public CustomerEntity updateCustomer(CustomerEntity customerEntity) {

		return customerJpaDao.save(customerEntity);
	}

	@Override
	public List<CustomerEntity> deleteCustomer(int customerId) {
		customerJpaDao.deleteById(customerId);
		List<CustomerEntity> allCustomers = customerJpaDao.findAll();
		if(allCustomers.isEmpty()) {
			throw new CustomerNotFoundException("No Customers Found!!");
		}
		return allCustomers;
	}

	@Override
	public List<CustomerEntity> viewCustomers() {

		List<CustomerEntity> custList = customerJpaDao.findAll();
		if (custList.isEmpty()) {
			throw new CustomerNotFoundException("No customers found!!");
		}
		return custList;
	}

	@Override
	public CustomerEntity viewCustomer(int customerId) {

		Optional<CustomerEntity> result = customerJpaDao.findById(customerId);
		if (result.isPresent()) {
			return result.get();
		} else {
			throw new CustomerNotFoundException("No customer found!!");

		}
	}

	@Override
	public CustomerEntity fetchalldetails(int userId) {
		// TODO Auto-generated method stub
		return customerJpaDao.fetchalldetails(userId);
	}

	
}
