package com.cabbooking.service;

import java.util.List;

import com.cabbooking.entities.CustomerEntity;
import com.cabbooking.entities.DriverEntity;

public interface IDriverService {

	public DriverEntity insertDriver(DriverEntity driver);

	public DriverEntity updateDriver(DriverEntity driver);

	public List<DriverEntity> deleteDriver(int driverId);

	public List<DriverEntity> viewBestDrivers();

	public DriverEntity viewDriver(int driverId);

	public List<DriverEntity> viewDrivers();

	DriverEntity fetchalldetails(int userId);
}
