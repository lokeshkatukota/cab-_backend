package com.cabbooking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cabbooking.entities.UserEntity;
import com.cabbooking.jpadao.IUserJpaDao;

@Service
public class UserServiceImpl implements IUserService{

	@Autowired
	IUserJpaDao userJpaDao;

	public UserServiceImpl() {
		super();
	}

	@Override
	public UserEntity addUser(UserEntity user) {
		// TODO Auto-generated method stub
		return userJpaDao.save(user);
	}

	@Override
	public List<UserEntity> getAllUsers() {
		// TODO Auto-generated method stub
		return userJpaDao.findAll();
	}

	@Override
	public UserEntity findByUsername(String username) {
		// TODO Auto-generated method stub
		return userJpaDao.findByUsername(username);
	}

	@Override
	public int getUserId(String username) {
		// TODO Auto-generated method stub
		return userJpaDao.getUserId(username);
	}

}
