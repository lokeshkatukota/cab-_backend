package com.cabbooking.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.repository.query.Param;

import com.cabbooking.entities.TripBookingEntity;

public interface ITripBookingService {

	public TripBookingEntity insertTripBooking(TripBookingEntity tripBookingPojo);

	public TripBookingEntity updateTripBooking(TripBookingEntity tripBookingPojo);

	public boolean deleteTripBooking(int tripBookingId);

	public List<TripBookingEntity> viewAllTripBooking();

	public List<TripBookingEntity> getTripsDatewise(LocalDateTime fromDateTime);
	
	public List<TripBookingEntity> getCustomerTrips( int customerId);

	public List<TripBookingEntity> getDriverTrips(int driverId);

}
