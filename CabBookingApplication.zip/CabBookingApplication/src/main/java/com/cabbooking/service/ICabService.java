package com.cabbooking.service;

import java.util.List;

import com.cabbooking.entities.CabEntity;
import com.cabbooking.entities.CustomerEntity;

public interface ICabService {
	
	public CabEntity insertCab(CabEntity cabEntity);

	public CabEntity updateCab(CabEntity cabEntity);

	public List<CabEntity> viewCabs();

	public int countCabsOfType(String carType);

	public List<CabEntity> deleteCab(int cabId);
	
	public CabEntity viewCab(int cabId);

}
