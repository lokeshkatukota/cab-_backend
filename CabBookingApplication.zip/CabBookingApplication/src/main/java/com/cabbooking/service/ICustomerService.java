package com.cabbooking.service;

import java.util.List;
import com.cabbooking.entities.CustomerEntity;

public interface ICustomerService {

	public CustomerEntity insertCustomer(CustomerEntity customer);

	public CustomerEntity updateCustomer(CustomerEntity customer);

	public List<CustomerEntity> deleteCustomer(int customerId);

	public List<CustomerEntity> viewCustomers();

	public CustomerEntity viewCustomer(int customerId);
	
	public CustomerEntity fetchalldetails(int userId);
	
	

}
