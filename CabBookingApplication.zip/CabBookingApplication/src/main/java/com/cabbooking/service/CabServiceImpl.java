package com.cabbooking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cabbooking.entities.CabEntity;
import com.cabbooking.entities.CustomerEntity;
import com.cabbooking.exceptions.CabNotFoundException;
import com.cabbooking.exceptions.CustomerNotFoundException;
import com.cabbooking.jpadao.ICabJpaDao;

@Service
public class CabServiceImpl implements ICabService {

	@Autowired
	ICabJpaDao cabJpaDao;

	@Override
	public CabEntity insertCab(CabEntity cabEntity) {

		cabEntity = cabJpaDao.save(cabEntity);
		return cabEntity;
	}

	@Override
	public CabEntity updateCab(CabEntity cabEntity) {

		cabEntity = cabJpaDao.save(cabEntity);
		return cabEntity;
	}

	@Override
	public List<CabEntity> deleteCab(int cabId) {
		cabJpaDao.deleteById(cabId);
		List<CabEntity> allCabs = cabJpaDao.findAll();
		if(allCabs.isEmpty()) {
			throw new CabNotFoundException("No Cab Found!!");
		}
		return allCabs;
	}

	@Override
	public List<CabEntity> viewCabs() {

		List<CabEntity> cabEntityList = cabJpaDao.findAll();
		if (cabEntityList.isEmpty()) {
			throw new CabNotFoundException("No cabs found!!");
		}
		return cabEntityList;
	}

	@Override
	public int countCabsOfType(String carType) {

		return cabJpaDao.findCountByType(carType);
	}

	@Override
	public CabEntity viewCab(int cabId) {
		// TODO Auto-generated method stub
		Optional<CabEntity> result = cabJpaDao.findById(cabId);
		if (result.isPresent()) {
			return result.get();
		} else {
			throw new CustomerNotFoundException("No cab found!!");

		}
	
	}

}
