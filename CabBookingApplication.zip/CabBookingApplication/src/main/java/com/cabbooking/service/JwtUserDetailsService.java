package com.cabbooking.service;

import java.util.ArrayList;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cabbooking.entities.UserEntity;
import com.cabbooking.jpadao.IUserJpaDao;
import com.cabbooking.pojo.UserPojo;



@Service
public class JwtUserDetailsService implements UserDetailsService {
	
	@Autowired
	private IUserJpaDao userJpaDao;

	@Autowired
	private PasswordEncoder bcryptEncoder;
	

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		System.out.println("username: " + username);
		UserEntity user = userJpaDao.findByUsername(username);
		
		System.out.println("DAO USER :" + user);
		if (user == null) {
			throw new UsernameNotFoundException("User not found with username: " + username);
		}
	
		return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(), 
				new ArrayList<>());
	}
	
	public UserEntity save(UserPojo user) {
		UserEntity newUser = new UserEntity();
		newUser.setUserId(user.getUserId());
		newUser.setUsername(user.getUsername());
		newUser.setPassword(bcryptEncoder.encode(user.getPassword()));
		newUser.setRole(user.getRole());
		return userJpaDao.save(newUser);
	}
	
	public UserPojo findByUserName(String username) {
		UserEntity userEntity= userJpaDao.findByUsername(username);
		UserPojo pojo= new UserPojo();
		BeanUtils.copyProperties(userEntity, pojo);
		return pojo;
				
	}
	
	
	

}
