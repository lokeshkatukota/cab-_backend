package com.cabbooking.service;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.cabbooking.entities.UserEntity;

public interface IUserService {
	
	public UserEntity addUser(UserEntity user);

	public List<UserEntity> getAllUsers();
	
	public UserEntity findByUsername(String username);

	public int getUserId(String username);
}
