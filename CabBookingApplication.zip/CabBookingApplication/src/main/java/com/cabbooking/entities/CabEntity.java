package com.cabbooking.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "cab_table")
public class CabEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cab_seq")
//	@SequenceGenerator(sequenceName = "CAB_TABLE_SEQ4", allocationSize = 1, name = "cab_seq")
	@Column(name = "cab_id")
	private int cabId;
   
	@Column(name = "car_type")
	private String carType;
    
	@NotNull(message="Specify the per kilometer rate!")
	@Column(name = "per_km_rate")
	private int perKmRate;
	
	public int getCabId() {
		return cabId;
	}

	public void setCabId(int cabId) {
		this.cabId = cabId;
	}

	public String getCarType() {
		return carType;
	}

	public void setCarType(String carType) {
		this.carType = carType;
	}

	public int getPerKmRate() {
		return perKmRate;
	}

	public void setPerKmRate(int perKmRate) {
		this.perKmRate = perKmRate;
	}

	public CabEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CabEntity(int cabId, String carType, int perKmRate) {
		super();
		this.cabId = cabId;
		this.carType = carType;
		this.perKmRate = perKmRate;
	}

	public CabEntity(int cabId, String carType) {
		super();
		this.cabId = cabId;
		this.carType = carType;
	}

	public CabEntity(String carType) {
		super();
		this.carType = carType;
	}

	@Override
	public String toString() {
		return "CabEntity [cabId=" + cabId + ", carType=" + carType + ", perKmRate=" + perKmRate + "]";
	}

}
