package com.cabbooking.entities;

import java.io.Serializable;

import com.cabbooking.pojo.UserPojo;

public class JwtResponse implements Serializable {

	private static final long serialVersionUID = -8091879091924046844L;
	private final String jwttoken;
	private UserPojo user;
	
	public JwtResponse(String jwttoken, UserPojo user) {
		super();
		this.jwttoken = jwttoken;
		this.user = user;
	}


	public String getToken() {
		return this.jwttoken;
	}


	public UserPojo getUser() {
		return user;
	}


	public void setUser(UserPojo user) {
		this.user = user;
	}


	public String getJwttoken() {
		return jwttoken;
	}
}
