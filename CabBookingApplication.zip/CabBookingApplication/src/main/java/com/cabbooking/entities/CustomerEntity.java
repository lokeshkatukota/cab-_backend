package com.cabbooking.entities;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "customer_table")
public class CustomerEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "customer_seq")
//	@SequenceGenerator(sequenceName = "CUSTOMER_TABLE_SEQ5", allocationSize = 1, name = "customer_seq")
	@Column(name = "customer_id")
	private int customerId;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id")
	private UserEntity userId;
    
	@NotNull(message="Username cannot be null!")
	@Column(name = "user_name")
	private String customerUserName;
    
	@NotNull(message="Password cannot be null!")
	@Column(name = "password")
	private String customerPassword;

	@Column(name = "address")
	private String customerAddress;
    
	@NotNull(message="Mobile number cannot be null!")
	@Column(name = "mobile_number")
	private int customerMobileNumber;
    
	@NotNull(message="Email cannot be null!")
	@Column(name = "email")
	private String customerEmail;

	@JsonBackReference
	@OneToMany(mappedBy = "customerEntity", fetch = FetchType.LAZY)
	private List<TripBookingEntity> customerTrips = new ArrayList<TripBookingEntity>();

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public UserEntity getUserId() {
		return userId;
	}

	public void setUserId(UserEntity userId) {
		this.userId = userId;
	}

	public String getCustomerUserName() {
		return customerUserName;
	}

	public void setCustomerUserName(String customerUserName) {
		this.customerUserName = customerUserName;
	}

	public String getCustomerPassword() {
		return customerPassword;
	}

	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public int getCustomerMobileNumber() {
		return customerMobileNumber;
	}

	public void setCustomerMobileNumber(int customerMobileNumber) {
		this.customerMobileNumber = customerMobileNumber;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public List<TripBookingEntity> getCustomerTrips() {
		return customerTrips;
	}

	public void setCustomerTrips(List<TripBookingEntity> customerTrips) {
		this.customerTrips = customerTrips;
	}

	public CustomerEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomerEntity(int customerId, UserEntity userId, String customerUserName, String customerPassword,
			String customerAddress, int customerMobileNumber, String customerEmail,
			List<TripBookingEntity> customerTrips) {
		super();
		this.customerId = customerId;
		this.userId = userId;
		this.customerUserName = customerUserName;
		this.customerPassword = customerPassword;
		this.customerAddress = customerAddress;
		this.customerMobileNumber = customerMobileNumber;
		this.customerEmail = customerEmail;
		this.customerTrips = customerTrips;
	}

	public CustomerEntity(int customerId, String customerUserName) {
		super();
		this.customerId = customerId;
		this.customerUserName = customerUserName;
	}

	public CustomerEntity(String customerUserName) {
		super();
		this.customerUserName = customerUserName;
	}

	public CustomerEntity(int customerId) {
		super();
		this.customerId = customerId;
	}

	@Override
	public String toString() {
		return "CustomerEntity [customerId=" + customerId + ", userId=" + userId + ", customerUserName="
				+ customerUserName + ", customerPassword=" + customerPassword + ", customerAddress=" + customerAddress
				+ ", customerMobileNumber=" + customerMobileNumber + ", customerEmail=" + customerEmail
				+ ", customerTrips=" + customerTrips + "]";
	}

}
