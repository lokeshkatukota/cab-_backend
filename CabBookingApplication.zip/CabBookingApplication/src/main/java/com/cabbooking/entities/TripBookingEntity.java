package com.cabbooking.entities;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "tripbooking_table")
public class TripBookingEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "trip_seq")
//	@SequenceGenerator(sequenceName = "TRIPBOOKING_TABLE_SEQ4", allocationSize = 1, name = "trip_seq")
	@Column(name = "tripbooking_id")
	private int tripBookingId;
    
	@NotNull(message="From location cannot be null!")
	@Column(name = "from_location")
	private String fromLocation;

	@NotNull(message="To location cannot be null!")
	@Column(name = "to_location")
	private String toLocation;
	
	@NotNull(message="From date cannot be null!")
	@Column(name = "from_date_time")
	private LocalDateTime fromDateTime;

	@NotNull(message="To date cannot be null!")
	@Column(name = "to_date_time")
	private LocalDateTime toDateTime;

	@Column(name = "distance_in_km")
	private float distanceInKm;

	@Column(name = "bill")
	private float bill;
	
	@Column(name="status")
	private String status;

	@ManyToOne
	@JoinColumn(name = "customer_id") // foreign key
	private CustomerEntity customerEntity;

	@ManyToOne
	@JoinColumn(name = "driver_id") // foreign key
	private DriverEntity driverEntity;

	public int getTripBookingId() {
		return tripBookingId;
	}

	public void setTripBookingId(int tripBookingId) {
		this.tripBookingId = tripBookingId;
	}

	public String getFromLocation() {
		return fromLocation;
	}

	public void setFromLocation(String fromLocation) {
		this.fromLocation = fromLocation;
	}

	public String getToLocation() {
		return toLocation;
	}

	public void setToLocation(String toLocation) {
		this.toLocation = toLocation;
	}

	public LocalDateTime getFromDateTime() {
		return fromDateTime;
	}

	public void setFromDateTime(LocalDateTime fromDateTime) {
		this.fromDateTime = fromDateTime;
	}

	public LocalDateTime getToDateTime() {
		return toDateTime;
	}

	public void setToDateTime(LocalDateTime toDateTime) {
		this.toDateTime = toDateTime;
	}

	public float getDistanceInKm() {
		return distanceInKm;
	}

	public void setDistanceInKm(float distanceInKm) {
		this.distanceInKm = distanceInKm;
	}

	public float getBill() {
		return bill;
	}

	public void setBill(float bill) {
		this.bill = bill;
	}

	public CustomerEntity getCustomerEntity() {
		return customerEntity;
	}

	public void setCustomerEntity(CustomerEntity customerEntity) {
		this.customerEntity = customerEntity;
	}

	public DriverEntity getDriverEntity() {
		return driverEntity;
	}

	public void setDriverEntity(DriverEntity driverEntity) {
		this.driverEntity = driverEntity;
	}
	

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public TripBookingEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public TripBookingEntity(int tripBookingId,  String fromLocation,
			 String toLocation,
			 LocalDateTime fromDateTime,
			LocalDateTime toDateTime, float distanceInKm, float bill,
			String status, CustomerEntity customerEntity, DriverEntity driverEntity) {
		super();
		this.tripBookingId = tripBookingId;
		this.fromLocation = fromLocation;
		this.toLocation = toLocation;
		this.fromDateTime = fromDateTime;
		this.toDateTime = toDateTime;
		this.distanceInKm = distanceInKm;
		this.bill = bill;
		this.status = status;
		this.customerEntity = customerEntity;
		this.driverEntity = driverEntity;
	}

	public TripBookingEntity(int tripBookingId, String fromLocation, String toLocation) {
		super();
		this.tripBookingId = tripBookingId;
		this.fromLocation = fromLocation;
		this.toLocation = toLocation;
	}

	public TripBookingEntity(String fromLocation, String toLocation) {
		super();
		this.fromLocation = fromLocation;
		this.toLocation = toLocation;
	}

	public TripBookingEntity(int tripBookingId, String toLocation) {
		super();
		this.tripBookingId = tripBookingId;
		this.toLocation = toLocation;
	}

	@Override
	public String toString() {
		return "TripBookingEntity [tripBookingId=" + tripBookingId + ", fromLocation=" + fromLocation + ", toLocation="
				+ toLocation + ", fromDateTime=" + fromDateTime + ", toDateTime=" + toDateTime + ", distanceInKm="
				+ distanceInKm + ", bill=" + bill + ", status=" + status + ", customerEntity=" + customerEntity
				+ ", driverEntity=" + driverEntity + "]";
	}

    
}
