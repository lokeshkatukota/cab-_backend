package com.cabbooking.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "admin_table")
public class AdminEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "admin_seq")
//	@SequenceGenerator(sequenceName = "ADMIN_TABLE_SEQ5", allocationSize = 1, name = "admin_seq")
	@Column(name = "admin_id")
	private int adminId;
    
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id")
	private UserEntity userId;
    
	@NotNull(message="Username cannot be null!")
	@Column(name = "user_name")
	private String adminUserName;
    
	@NotNull(message="Password cannot be null!")
	@Column(name = "password")
	private String adminPassword;

	@Column(name = "address")
	private String adminAddress;
    
	@NotNull(message="Mobile number cannot be null!")
	@Column(name = "mobile_number")
	private int adminMobileNumber;
    
	@NotNull(message="Emailcannot be null!")
	@Column(name = "email")
	private String adminEmail;

	public int getAdminId() {
		return adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public UserEntity getUserId() {
		return userId;
	}

	public void setUserId(UserEntity userId) {
		this.userId = userId;
	}

	public String getAdminUserName() {
		return adminUserName;
	}

	public void setAdminUserName(String adminUserName) {
		this.adminUserName = adminUserName;
	}

	public String getAdminPassword() {
		return adminPassword;
	}

	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}

	public String getAdminAddress() {
		return adminAddress;
	}

	public void setAdminAddress(String adminAddress) {
		this.adminAddress = adminAddress;
	}

	public int getAdminMobileNumber() {
		return adminMobileNumber;
	}

	public void setAdminMobileNumber(int adminMobileNumber) {
		this.adminMobileNumber = adminMobileNumber;
	}

	public String getAdminEmail() {
		return adminEmail;
	}

	public void setAdminEmail(String adminEmail) {
		this.adminEmail = adminEmail;
	}

	public AdminEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AdminEntity(int adminId, UserEntity userId, String adminUserName, String adminPassword, String adminAddress,
			int adminMobileNumber, String adminEmail) {
		super();
		this.adminId = adminId;
		this.userId = userId;
		this.adminUserName = adminUserName;
		this.adminPassword = adminPassword;
		this.adminAddress = adminAddress;
		this.adminMobileNumber = adminMobileNumber;
		this.adminEmail = adminEmail;
	}

	public AdminEntity(int adminId, String adminUserName) {
		super();
		this.adminId = adminId;
		this.adminUserName = adminUserName;
	}

	public AdminEntity(String adminUserName) {
		super();
		this.adminUserName = adminUserName;
	}

	@Override
	public String toString() {
		return "AdminEntity [adminId=" + adminId + ", userId=" + userId + ", adminUserName=" + adminUserName
				+ ", adminPassword=" + adminPassword + ", adminAddress=" + adminAddress + ", adminMobileNumber="
				+ adminMobileNumber + ", adminEmail=" + adminEmail + "]";
	}

}
