package com.cabbooking.entities;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "driver_table")
public class DriverEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "driver_seq")
//	@SequenceGenerator(sequenceName = "DRIVER_TABLE_SEQ5", allocationSize = 1, name = "driver_seq")
	@Column(name = "driver_id")
	private int driverId;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id")
	private UserEntity userId;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "cab_id")
	private CabEntity cab;
    
	@NotNull(message="Username cannot be null!")
	@Column(name = "user_name")
	private String driverUserName;
    
	@NotNull(message="Password cannot be null!")
	@Column(name = "password")
	private String driverPassword;

	@Column(name = "address")
	private String driverAddress;
    
	@NotNull(message="Mobile number cannot be null!")
	@Column(name = "mobile_number")
	private int driverMobileNumber;
    
	@NotNull(message="Email cannot be null!")
	@Column(name = "email")
	private String driverEmail;
    
	@NotNull(message="Licence number cannot be null!")
	@Column(name = "licence_number")
	private int driverLicenceNumber;

	@Column(name = "rating")
	private int driverRating;

	@JsonBackReference
	@OneToMany(mappedBy = "driverEntity", fetch = FetchType.EAGER)
	private List<TripBookingEntity> driverTrips = new ArrayList<>();

	public int getDriverId() {
		return driverId;
	}

	public void setDriverId(int driverId) {
		this.driverId = driverId;
	}

	public UserEntity getUserId() {
		return userId;
	}

	public void setUserId(UserEntity userId) {
		this.userId = userId;
	}

	public CabEntity getCab() {
		return cab;
	}

	public void setCab(CabEntity cab) {
		this.cab = cab;
	}

	public String getDriverUserName() {
		return driverUserName;
	}

	public void setDriverUserName(String driverUserName) {
		this.driverUserName = driverUserName;
	}

	public String getDriverPassword() {
		return driverPassword;
	}

	public void setDriverPassword(String driverPassword) {
		this.driverPassword = driverPassword;
	}

	public String getDriverAddress() {
		return driverAddress;
	}

	public void setDriverAddress(String driverAddress) {
		this.driverAddress = driverAddress;
	}

	public int getDriverMobileNumber() {
		return driverMobileNumber;
	}

	public void setDriverMobileNumber(int driverMobileNumber) {
		this.driverMobileNumber = driverMobileNumber;
	}

	public String getDriverEmail() {
		return driverEmail;
	}

	public void setDriverEmail(String driverEmail) {
		this.driverEmail = driverEmail;
	}

	public int getDriverLicenceNumber() {
		return driverLicenceNumber;
	}

	public void setDriverLicenceNumber(int driverLicenceNumber) {
		this.driverLicenceNumber = driverLicenceNumber;
	}

	public int getDriverRating() {
		return driverRating;
	}

	public void setDriverRating(int driverRating) {
		this.driverRating = driverRating;
	}

	public List<TripBookingEntity> getDriverTrips() {
		return driverTrips;
	}

	public void setDriverTrips(List<TripBookingEntity> driverTrips) {
		this.driverTrips = driverTrips;
	}

	public DriverEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DriverEntity(int driverId, UserEntity userId, CabEntity cab, String driverUserName, String driverPassword,
			String driverAddress, int driverMobileNumber, String driverEmail, int driverLicenceNumber, int driverRating,
			List<TripBookingEntity> driverTrips) {
		super();
		this.driverId = driverId;
		this.userId = userId;
		this.cab = cab;
		this.driverUserName = driverUserName;
		this.driverPassword = driverPassword;
		this.driverAddress = driverAddress;
		this.driverMobileNumber = driverMobileNumber;
		this.driverEmail = driverEmail;
		this.driverLicenceNumber = driverLicenceNumber;
		this.driverRating = driverRating;
		this.driverTrips = driverTrips;
	}

	public DriverEntity(int driverId, String driverUserName) {
		super();
		this.driverId = driverId;
		this.driverUserName = driverUserName;
	}

	public DriverEntity(String driverUserName) {
		super();
		this.driverUserName = driverUserName;
	}

	public DriverEntity(int driverId) {
		super();
		this.driverId = driverId;
	}

	@Override
	public String toString() {
		return "DriverEntity [driverId=" + driverId + ", userId=" + userId + ", cab=" + cab + ", driverUserName="
				+ driverUserName + ", driverPassword=" + driverPassword + ", driverAddress=" + driverAddress
				+ ", driverMobileNumber=" + driverMobileNumber + ", driverEmail=" + driverEmail
				+ ", driverLicenceNumber=" + driverLicenceNumber + ", driverRating=" + driverRating + ", driverTrips="
				+ driverTrips + "]";
	}

}
