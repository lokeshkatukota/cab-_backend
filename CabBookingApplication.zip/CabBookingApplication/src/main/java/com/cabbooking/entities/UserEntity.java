package com.cabbooking.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "user_table")
public class UserEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_seq")
//	@SequenceGenerator(sequenceName = "USER_TABLE_SEQ4", allocationSize = 1, name = "user_seq")
	@Column(name = "user_id")
	private int userId;

	@NotNull(message = "User Id Is Mandatory!!")
	@Column(name = "username")
	private String username;
	
	@NotNull(message = "Password Is Mandatory!!")
	@Column(name = "password")
	private String password;
	
	@NotNull(message = "Role Should Be Mentioned!!")
	@Column(name = "role")
	private String role;
	public UserEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public UserEntity(int userId, String username, String password, String role) {
		super();
		this.userId = userId;
		this.username = username;
		this.password = password;
		this.role = role;
	}
	
	
	

}
