package com.cabbooking.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cabbooking.entities.CustomerEntity;
import com.cabbooking.entities.DriverEntity;
import com.cabbooking.service.IDriverService;

@CrossOrigin
@RestController
@RequestMapping("/api/driver")
public class DriverController {

	@Autowired
	IDriverService driverService;

	// Get all drivers
	@GetMapping("/getall")
	public List<DriverEntity> getAllDrivers() {
		return driverService.viewDrivers();
	}

	// Insert driver
	@PostMapping("/add")
	public DriverEntity addDriver(@Valid @RequestBody DriverEntity driver) {
		return driverService.insertDriver(driver);
	}

	// Update driver details
	@PutMapping("/update")
	DriverEntity updateDriver(@RequestBody DriverEntity driver) {
		return driverService.updateDriver(driver);
	}

	// Delete a driver
	@DeleteMapping("/delete/{driverId}")
	public List<DriverEntity> deleteDriver(int driverId) {
		return driverService.deleteDriver(driverId);
	}

	// View drivers with rating greater than 4
	@GetMapping("/bestdrivers")
	public List<DriverEntity> viewBestDrivers() {
		return driverService.viewBestDrivers();
	}

	// Fetch one driver
	@GetMapping("/getone/{driverId}")
	public DriverEntity getDriver(@PathVariable("driverId") int driverId) {
		return driverService.viewDriver(driverId);
	}
	
	@GetMapping("/getdetails/{userId}")
	public DriverEntity getDriverDetails(@PathVariable ("userId") int userId) {
		return driverService.fetchalldetails(userId);
	}

}
