package com.cabbooking.controller;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cabbooking.entities.CabEntity;
import com.cabbooking.entities.CustomerEntity;
import com.cabbooking.service.ICabService;

@CrossOrigin
@RestController
@RequestMapping("/api/cab")
public class CabController {

	@Autowired
	ICabService cabService;

	// Insert cab
	@PostMapping("/add")
	public CabEntity addCab(@Valid @RequestBody CabEntity cab) {
		return cabService.insertCab(cab);
	}

	// Update cab details
	@PutMapping("/update")
	public CabEntity updateCab(@RequestBody CabEntity cab) {
		return cabService.updateCab(cab);
	}

	// view all cars
	@GetMapping("/getall")
	public List<CabEntity> viewCabs() {
		return cabService.viewCabs();
	}

	// Delete the cab
	@DeleteMapping("/delete/{cabId}")
	public List<CabEntity> deleteCab(@PathVariable("cabId") int cabId) {
		return cabService.deleteCab(cabId);
	}

	@GetMapping("/getone/{cabId}")
	public CabEntity getCab(@PathVariable("cabId") int cabId) {
		return cabService.viewCab(cabId);
	}

	// Count based on car type
	@GetMapping("/count/{carType}")
	public int countCars(@PathVariable("carType") String carType) {
		return cabService.countCabsOfType(carType);
	}

}
