package com.cabbooking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cabbooking.entities.UserEntity;
import com.cabbooking.service.IUserService;

@CrossOrigin(origins = "http://localhost:4200")  
@RestController
@RequestMapping("/api/user")
public class UserController {
	
	@Autowired
	IUserService userService;
	
	@GetMapping("/getbyname/{username}")
	public UserEntity findByUsername(@PathVariable ("username") String username) {
		return userService.findByUsername(username);
	}
	
	@GetMapping("/getuserid/{username}")
	public int getUserId(@PathVariable ("username") String username) {
		return userService.getUserId(username);
	}
}
