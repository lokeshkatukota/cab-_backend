package com.cabbooking.controller;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cabbooking.entities.AdminEntity;
import com.cabbooking.service.IAdminService;

@CrossOrigin
@RestController
@RequestMapping("/api/admin")
public class AdminController {

	@Autowired
	IAdminService adminService;

	// Insert an Admin
	@PostMapping("/add")
	public AdminEntity addAdmin(@Valid @RequestBody AdminEntity admin) {
		return adminService.insertAdmin(admin);
	}

	// Get all Admins
	@GetMapping("/getall")
	public List<AdminEntity> getAllAdmins() {
		return adminService.viewAdmins();
	}

	// Update Admin details
	@PutMapping("/update")
	public AdminEntity updateAdmin(@RequestBody AdminEntity admin) {
		return adminService.updateAdmin(admin);
	}

	// Delete an Admin
	@DeleteMapping("/delete/{adminId}")
	public boolean deleteAdmin(@PathVariable("adminId") int adminId) {
		return adminService.deleteAdmin(adminId);
	}

}
