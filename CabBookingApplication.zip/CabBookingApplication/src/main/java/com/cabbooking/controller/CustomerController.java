package com.cabbooking.controller;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cabbooking.entities.CustomerEntity;
import com.cabbooking.service.ICustomerService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/customer")
public class CustomerController {

	@Autowired
	ICustomerService customerService;

	// Insert customer
	@PostMapping("/add")
	public CustomerEntity addCustomer(@Valid @RequestBody CustomerEntity customer) {
		return customerService.insertCustomer(customer);
	}

	// Get all customers
	@GetMapping("/getall")
	List<CustomerEntity> getAllCustomers() {
		return customerService.viewCustomers();
	}

	// Update a customer
	@PutMapping("/update")
	public CustomerEntity updateCustomer(@RequestBody CustomerEntity customer) {
		return customerService.updateCustomer(customer);
	}

	// Delete a customer
	@DeleteMapping("/delete/{custId}")
	public List<CustomerEntity> deleteCustomer(@PathVariable("custId") int customerId) {
		return customerService.deleteCustomer(customerId);
	}

	// Fetch one customer
	@GetMapping("/getone/{custId}")
	public CustomerEntity getCustomer(@PathVariable("custId") int customerId) {
		return customerService.viewCustomer(customerId);
	}
	
	@GetMapping("/getdetails/{userId}")
	public CustomerEntity getCustomerDetails(@PathVariable ("userId") int userId) {
		return customerService.fetchalldetails(userId);
	}
	
	

}
