   package com.cabbooking.controller;


import java.time.LocalDateTime;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cabbooking.entities.TripBookingEntity;
import com.cabbooking.service.ITripBookingService;

@CrossOrigin
@RestController
@RequestMapping("/api/trips")
public class TripBookingController {

	@Autowired
	ITripBookingService tripBookingService;

	// Insert trip details
	@PostMapping("/add")
	public TripBookingEntity addTrips(@Valid @RequestBody TripBookingEntity tripBookingEntity) {
		return tripBookingService.insertTripBooking(tripBookingEntity);
	}

	// Update trip details
	@PutMapping("/update")
	public TripBookingEntity updateTripBooking(@RequestBody TripBookingEntity tripBookingEntity) {
		return tripBookingService.updateTripBooking(tripBookingEntity);
	}

	// Cancel/delete a trip
	@DeleteMapping("/delete/{tripId}")
	public boolean deleteTripBooking(@PathVariable("tripId") int tripBookingId) {
		return tripBookingService.deleteTripBooking(tripBookingId);
	}

	// Get all trips booked
	@GetMapping("/viewalltrips")
	public List<TripBookingEntity> viewAllTripBooking() {
		return tripBookingService.viewAllTripBooking();
	}

	// Get trip Datewise
	@GetMapping("/getDateWise/{fromDateTime}")
	public List<TripBookingEntity> getTripsDatewise(@PathVariable("fromDateTime") LocalDateTime fromDateTime) {
		return tripBookingService.getTripsDatewise(fromDateTime);
	}
	
	@GetMapping("/getcustomertrips/{customerId}")
	public List<TripBookingEntity> getCustomerTrips(@PathVariable ("customerId") int customerId){
		return tripBookingService.getCustomerTrips(customerId);
	}
	
	@GetMapping("/getdrivertrips/{driverId}")
	public List<TripBookingEntity> getDriverTrips(@PathVariable ("driverId") int driverId){
		return tripBookingService.getDriverTrips(driverId);
	}


}
 