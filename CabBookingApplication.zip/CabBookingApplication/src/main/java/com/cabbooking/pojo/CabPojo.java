package com.cabbooking.pojo;

import javax.validation.constraints.NotNull;

public class CabPojo {

	private int cabId;

	@NotNull(message = "Field required")
	private String carType;

	@NotNull(message = "Field required")
	private int perKmRate;

	public int getCabId() {
		return cabId;
	}

	public void setCabId(int cabId) {
		this.cabId = cabId;
	}

	public String getCarType() {
		return carType;
	}

	public void setCarType(String carType) {
		this.carType = carType;
	}

	public int getPerKmRate() {
		return perKmRate;
	}

	public void setPerKmRate(int perKmRate) {
		this.perKmRate = perKmRate;
	}

	public CabPojo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CabPojo(int cabId, String carType, int perKmRate) {
		super();
		this.cabId = cabId;
		this.carType = carType;
		this.perKmRate = perKmRate;
	}

	@Override
	public String toString() {
		return "CabPojo [cabId=" + cabId + ", carType=" + carType + ", perKmRate=" + perKmRate + "]";
	}

}
