package com.cabbooking.pojo;

import java.util.ArrayList;
import java.util.List;
import javax.validation.constraints.NotNull;

public class DriverPojo {

	private int driverId;

	private UserPojo userId;

	private CabPojo cab;

	@NotNull(message = "Username cannot be null!")
	private String driverUserName;

	@NotNull(message = "Password cannot be null")
	private String driverPassword;

	private String driverAddress;

	@NotNull(message = "Mobile Number is required!")
	private int driverMobileNumber;

	@NotNull(message = "Email Id cannot be null!")
	private String driverEmail;

	@NotNull(message = "Licence number cannot be null!")
	private int driverLicenceNumber;

	private int driverRating;

	private List<TripBookingPojo> driverTrips = new ArrayList<>();

	public int getDriverId() {
		return driverId;
	}

	public void setDriverId(int driverId) {
		this.driverId = driverId;
	}

	public UserPojo getUserId() {
		return userId;
	}

	public void setUserId(UserPojo userId) {
		this.userId = userId;
	}

	public CabPojo getCab() {
		return cab;
	}

	public void setCab(CabPojo cab) {
		this.cab = cab;
	}

	public String getDriverUserName() {
		return driverUserName;
	}

	public void setDriverUserName(String driverUserName) {
		this.driverUserName = driverUserName;
	}

	public String getDriverPassword() {
		return driverPassword;
	}

	public void setDriverPassword(String driverPassword) {
		this.driverPassword = driverPassword;
	}

	public String getDriverAddress() {
		return driverAddress;
	}

	public void setDriverAddress(String driverAddress) {
		this.driverAddress = driverAddress;
	}

	public int getDriverMobileNumber() {
		return driverMobileNumber;
	}

	public void setDriverMobileNumber(int driverMobileNumber) {
		this.driverMobileNumber = driverMobileNumber;
	}

	public String getDriverEmail() {
		return driverEmail;
	}

	public void setDriverEmail(String driverEmail) {
		this.driverEmail = driverEmail;
	}

	public int getDriverLicenceNumber() {
		return driverLicenceNumber;
	}

	public void setDriverLicenceNumber(int driverLicenceNumber) {
		this.driverLicenceNumber = driverLicenceNumber;
	}

	public int getDriverRating() {
		return driverRating;
	}

	public void setDriverRating(int driverRating) {
		this.driverRating = driverRating;
	}

	public List<TripBookingPojo> getDriverTrips() {
		return driverTrips;
	}

	public void setDriverTrips(List<TripBookingPojo> driverTrips) {
		this.driverTrips = driverTrips;
	}

	

	public DriverPojo( String driverUserName,
			 String driverPassword) {
		super();
		this.driverUserName = driverUserName;
		this.driverPassword = driverPassword;
	}

	public DriverPojo(int driverId, UserPojo userId, CabPojo cab, String driverUserName, String driverPassword,
			String driverAddress, int driverMobileNumber, String driverEmail, int driverLicenceNumber, int driverRating,
			List<TripBookingPojo> driverTrips) {
		super();
		this.driverId = driverId;
		this.userId = userId;
		this.cab = cab;
		this.driverUserName = driverUserName;
		this.driverPassword = driverPassword;
		this.driverAddress = driverAddress;
		this.driverMobileNumber = driverMobileNumber;
		this.driverEmail = driverEmail;
		this.driverLicenceNumber = driverLicenceNumber;
		this.driverRating = driverRating;
		this.driverTrips = driverTrips;
	}

	@Override
	public String toString() {
		return "DriverPojo [driverId=" + driverId + ", userId=" + userId + ", cab=" + cab + ", driverUserName="
				+ driverUserName + ", driverPassword=" + driverPassword + ", driverAddress=" + driverAddress
				+ ", driverMobileNumber=" + driverMobileNumber + ", driverEmail=" + driverEmail
				+ ", driverLicenceNumber=" + driverLicenceNumber + ", driverRating=" + driverRating + ", driverTrips="
				+ driverTrips + "]";
	}

}
