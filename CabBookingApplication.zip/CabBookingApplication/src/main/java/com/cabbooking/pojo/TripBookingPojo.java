package com.cabbooking.pojo;

import java.time.LocalDateTime;

import javax.validation.constraints.NotNull;

public class TripBookingPojo {

	private int tripBookingId;

	private CustomerPojo customerPojo;

	private DriverPojo driverPojo;

	@NotNull(message = "Field required!")
	private String fromLocation;

	@NotNull(message = "Field required!")
	private String toLocation;

	@NotNull(message = "Field required!")
	private LocalDateTime fromDateTime;

	@NotNull(message = "Field required!")
	private LocalDateTime toDateTime;
	private float distanceInKm;
	private float bill;
	private String status;

	public int getTripBookingId() {
		return tripBookingId;
	}

	public void setTripBookingId(int tripBookingId) {
		this.tripBookingId = tripBookingId;
	}

	public CustomerPojo getCustomerPojo() {
		return customerPojo;
	}

	public void setCustomerPojo(CustomerPojo customerPojo) {
		this.customerPojo = customerPojo;
	}

	public DriverPojo getDriverPojo() {
		return driverPojo;
	}

	public void setDriverPojo(DriverPojo driverPojo) {
		this.driverPojo = driverPojo;
	}

	public String getFromLocation() {
		return fromLocation;
	}

	public void setFromLocation(String fromLocation) {
		this.fromLocation = fromLocation;
	}

	public String getToLocation() {
		return toLocation;
	}

	public void setToLocation(String toLocation) {
		this.toLocation = toLocation;
	}

	public LocalDateTime getFromDateTime() {
		return fromDateTime;
	}

	public void setFromDateTime(LocalDateTime fromDateTime) {
		this.fromDateTime = fromDateTime;
	}

	public LocalDateTime getToDateTime() {
		return toDateTime;
	}

	public void setToDateTime(LocalDateTime toDateTime) {
		this.toDateTime = toDateTime;
	}

	public float getDistanceInKm() {
		return distanceInKm;
	}

	public void setDistanceInKm(float distanceInKm) {
		this.distanceInKm = distanceInKm;
	}

	public float getBill() {
		return bill;
	}

	public void setBill(float bill) {
		this.bill = bill;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public TripBookingPojo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TripBookingPojo(int tripBookingId, CustomerPojo customerPojo, DriverPojo driverPojo,
			 String fromLocation,
			 String toLocation,
			 LocalDateTime fromDateTime,
			 LocalDateTime toDateTime, float distanceInKm, float bill,
			String status) {
		super();
		this.tripBookingId = tripBookingId;
		this.customerPojo = customerPojo;
		this.driverPojo = driverPojo;
		this.fromLocation = fromLocation;
		this.toLocation = toLocation;
		this.fromDateTime = fromDateTime;
		this.toDateTime = toDateTime;
		this.distanceInKm = distanceInKm;
		this.bill = bill;
		this.status = status;
	}

	@Override
	public String toString() {
		return "TripBookingPojo [tripBookingId=" + tripBookingId + ", customerPojo=" + customerPojo + ", driverPojo="
				+ driverPojo + ", fromLocation=" + fromLocation + ", toLocation=" + toLocation + ", fromDateTime="
				+ fromDateTime + ", toDateTime=" + toDateTime + ", distanceInKm=" + distanceInKm + ", bill=" + bill
				+ ", status=" + status + "]";
	}

	

}
