package com.cabbooking.pojo;

import java.util.ArrayList;
import java.util.List;
import javax.validation.constraints.NotNull;

public class CustomerPojo {

	private int customerId;

	private UserPojo userId;

	@NotNull(message = "Username cannot be null!")
	private String customerUserName;

	@NotNull(message = "Password cannot be null!")
	private String customerPassword;

	@NotNull(message = "Address cannot be null!")
	private String customerAddress;

	@NotNull(message = "Mobile Number cannot be null!")
	private int customerMobileNumber;

	@NotNull(message = "Email cannot be null!")
	private String customerEmail;

	private List<TripBookingPojo> customerTrips = new ArrayList<TripBookingPojo>();

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public UserPojo getUserId() {
		return userId;
	}

	public void setUserId(UserPojo userId) {
		this.userId = userId;
	}

	public String getCustomerUserName() {
		return customerUserName;
	}

	public void setCustomerUserName(String customerUserName) {
		this.customerUserName = customerUserName;
	}

	public String getCustomerPassword() {
		return customerPassword;
	}

	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public int getCustomerMobileNumber() {
		return customerMobileNumber;
	}

	public void setCustomerMobileNumber(int customerMobileNumber) {
		this.customerMobileNumber = customerMobileNumber;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public List<TripBookingPojo> getCustomerTrips() {
		return customerTrips;
	}

	public void setCustomerTrips(List<TripBookingPojo> customerTrips) {
		this.customerTrips = customerTrips;
	}

	

	public CustomerPojo( String customerUserName,
			String customerPassword) {
		super();
		this.customerUserName = customerUserName;
		this.customerPassword = customerPassword;
	}

	public CustomerPojo(int customerId, UserPojo userId, String customerUserName, String customerPassword,
			String customerAddress, int customerMobileNumber, String customerEmail,
			List<TripBookingPojo> customerTrips) {
		super();
		this.customerId = customerId;
		this.userId = userId;
		this.customerUserName = customerUserName;
		this.customerPassword = customerPassword;
		this.customerAddress = customerAddress;
		this.customerMobileNumber = customerMobileNumber;
		this.customerEmail = customerEmail;
		this.customerTrips = customerTrips;
	}

	@Override
	public String toString() {
		return "CustomerPojo [customerId=" + customerId + ", userId=" + userId + ", customerUserName="
				+ customerUserName + ", customerPassword=" + customerPassword + ", customerAddress=" + customerAddress
				+ ", customerMobileNumber=" + customerMobileNumber + ", customerEmail=" + customerEmail
				+ ", customerTrips=" + customerTrips + "]";
	}

}
