package com.cabbooking.pojo;

public class LoginPojo {

}
