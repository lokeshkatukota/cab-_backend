package com.cabbooking.pojo;

import javax.validation.constraints.NotNull;

public class AdminPojo {

	private int adminId;
	
	private UserPojo userId;

	@NotNull(message = "Username cannot be null!")
	private String adminUserName;

	@NotNull(message = "Password cannot be null!")
	private String adminPassword;

	private String adminAddress;

	@NotNull(message = "Mobile Number is required!")
	private int adminMobileNumber;

	@NotNull(message = "Email Id is required!")
	private String adminEmail;

	public int getAdminId() {
		return adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public UserPojo getUserId() {
		return userId;
	}

	public void setUserId(UserPojo userId) {
		this.userId = userId;
	}

	public String getAdminUserName() {
		return adminUserName;
	}

	public void setAdminUserName(String adminUserName) {
		this.adminUserName = adminUserName;
	}

	public String getAdminPassword() {
		return adminPassword;
	}

	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}

	public String getAdminAddress() {
		return adminAddress;
	}

	public void setAdminAddress(String adminAddress) {
		this.adminAddress = adminAddress;
	}

	public int getAdminMobileNumber() {
		return adminMobileNumber;
	}

	public void setAdminMobileNumber(int adminMobileNumber) {
		this.adminMobileNumber = adminMobileNumber;
	}

	public String getAdminEmail() {
		return adminEmail;
	}

	public void setAdminEmail(String adminEmail) {
		this.adminEmail = adminEmail;
	}

	public AdminPojo(String adminUserName, String adminPassword) {
		super();
		// TODO Auto-generated constructor stub
		this.adminUserName=adminUserName;
		this.adminPassword=adminPassword;
	}

	public AdminPojo(int adminId, UserPojo userId, String adminUserName, String adminPassword, String adminAddress,
			int adminMobileNumber, String adminEmail) {
		super();
		this.adminId = adminId;
		this.userId = userId;
		this.adminUserName = adminUserName;
		this.adminPassword = adminPassword;
		this.adminAddress = adminAddress;
		this.adminMobileNumber = adminMobileNumber;
		this.adminEmail = adminEmail;
	}

	@Override
	public String toString() {
		return "AdminPojo [adminId=" + adminId + ", userId=" + userId + ", adminUserName=" + adminUserName
				+ ", adminPassword=" + adminPassword + ", adminAddress=" + adminAddress + ", adminMobileNumber="
				+ adminMobileNumber + ", adminEmail=" + adminEmail + "]";
	}

}
