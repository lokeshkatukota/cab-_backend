package com.cabbooking.jpadao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cabbooking.entities.CustomerEntity;
import com.cabbooking.entities.DriverEntity;

@Repository
public interface IDriverJpaDao extends JpaRepository<DriverEntity, Integer> {

	@Query("from DriverEntity where driverRating>4")
	public List<DriverEntity> findByRating();
	
	@Query("from DriverEntity where userId in (select userId from UserEntity where userId=?1)")
	DriverEntity fetchalldetails(@Param ("userId") int userId);
	
	
	

}
