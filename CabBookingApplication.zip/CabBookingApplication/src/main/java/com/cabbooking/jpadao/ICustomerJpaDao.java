package com.cabbooking.jpadao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cabbooking.entities.CustomerEntity;

@Repository
public interface ICustomerJpaDao extends JpaRepository<CustomerEntity, Integer> {

	@Query("from CustomerEntity where userId in (select userId from UserEntity where userId=?1)")
	CustomerEntity fetchalldetails(@Param ("userId") int userId);
 
	
	
	
 
	
}