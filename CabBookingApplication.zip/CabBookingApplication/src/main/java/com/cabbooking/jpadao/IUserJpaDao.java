package com.cabbooking.jpadao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cabbooking.entities.UserEntity;

public interface IUserJpaDao extends JpaRepository<UserEntity, Integer> {
         
    @Query("select u from UserEntity u where u.username=:username")
	UserEntity findByUsername(@Param("username")String username);

	 @Query("select userId from UserEntity where username=?1")
     int getUserId(@Param ("username") String username);
	
	

}
