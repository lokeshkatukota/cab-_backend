package com.cabbooking.jpadao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cabbooking.entities.CabEntity;
import com.cabbooking.entities.TripBookingEntity;

@Repository
public interface ICabJpaDao extends JpaRepository<CabEntity, Integer> {

	@Query(value = "select count(car_type) from cab_table WHERE car_type=?1", nativeQuery = true)
	int findCountByType(String carType);

	@Query("from CabEntity where carType = ?1")
	List<TripBookingEntity> findAllTripsByCab(String carType);

}
