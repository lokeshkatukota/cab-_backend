package com.cabbooking.jpadao;

import java.time.LocalDateTime;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.cabbooking.entities.TripBookingEntity;

@Repository
public interface ITripBookingJpaDao extends JpaRepository<TripBookingEntity, Integer> {

	@Query("from TripBookingEntity where fromDateTime= ?1")
	List<TripBookingEntity> findAllTripsByDate(LocalDateTime fromDateTime);
	
	@Query("from TripBookingEntity where customerEntity in (select customerId from CustomerEntity where customerId=?1)")
	List<TripBookingEntity> getCustomerTrips(@Param ("customerId") int customerId);

	@Query("from TripBookingEntity where driverEntity in (select driverId from DriverEntity where driverId=?1)")
	List<TripBookingEntity> getDriverTrips(@Param ("driverId")int driverId);

}
