  package com.cabbooking;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import com.cabbooking.entities.AdminEntity;
import com.cabbooking.exceptions.AdminNotFoundException;
import com.cabbooking.jpadao.IAdminJpaDao;
import com.cabbooking.service.AdminServiceImpl;
import com.cabbooking.service.IAdminService;

@SpringBootTest
public class AdminServiceTest {
	@InjectMocks
	IAdminService adminService = new AdminServiceImpl();

	@Mock
	IAdminJpaDao adminJpaDao;

	@Test //Get all admins test
	public void testViewAdmins() {

		List<AdminEntity> mockAdmins = new ArrayList<>();
		mockAdmins.add(new AdminEntity(1, "ram"));
		mockAdmins.add(new AdminEntity(2, "sita"));
		mockAdmins.add(new AdminEntity(3, "john"));
		mockAdmins.add(new AdminEntity(4, "ram"));

		Mockito.when(adminJpaDao.findAll()).thenReturn(mockAdmins);
		assertEquals(4, adminService.viewAdmins().size());
	}

	@Test // Get all admins exception test
	public void testGetAllAdminException() {
		List<AdminEntity> mockAdmins = new ArrayList<>();

		Mockito.when(adminJpaDao.findAll()).thenReturn(mockAdmins);
		Exception exception = assertThrows(AdminNotFoundException.class, () -> adminService.viewAdmins());
		assertEquals("No admins found!!", exception.getMessage());
	}

	@Test // Admin insertion test
	public void testAddAdmin() {

		AdminEntity mockReturnAdmin = new AdminEntity(1, "ram");
		AdminEntity mockArgumentAdmin = new AdminEntity("ram");

		Mockito.when(adminJpaDao.save(mockArgumentAdmin)).thenReturn(mockReturnAdmin);
		assertEquals(1, adminService.insertAdmin(mockArgumentAdmin).getAdminId());
	}

	@Test //Admin updation test
	public void testUpdateAdmin() {

		AdminEntity mockReturnAdmin = new AdminEntity(1, "ram");
		AdminEntity mockArgumentAdmin = new AdminEntity(1, "ramkumar");

		Mockito.when(adminJpaDao.save(mockArgumentAdmin)).thenReturn(mockReturnAdmin);
		adminService.updateAdmin(mockArgumentAdmin);
		Mockito.verify(adminJpaDao, Mockito.times(1)).save(mockArgumentAdmin);

	}

	@Test //Admin deletion test
	public void testDeleteAdmin() {

		int id = 10;
		AdminEntity admin = new AdminEntity();

		if (admin.getAdminId() == id) {
			Mockito.doNothing().when(adminJpaDao).deleteById(id);
			adminService.deleteAdmin(id);
			Mockito.verify(adminJpaDao, Mockito.times(1)).deleteById(id);
		}
	}

}
