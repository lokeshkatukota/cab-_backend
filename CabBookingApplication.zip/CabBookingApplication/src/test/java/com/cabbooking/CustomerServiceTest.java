package com.cabbooking;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import com.cabbooking.entities.CustomerEntity;
import com.cabbooking.exceptions.CustomerNotFoundException;
import com.cabbooking.jpadao.ICustomerJpaDao;
import com.cabbooking.service.CustomerServiceImpl;
import com.cabbooking.service.ICustomerService;

@SpringBootTest
public class CustomerServiceTest {

	@InjectMocks
	ICustomerService customerService = new CustomerServiceImpl();

	@Mock
	ICustomerJpaDao customerJpaDao;

	@Test // Get all customers test
	public void testGetAllCustomer() {

		List<CustomerEntity> mockCustomer = new ArrayList<>();
		mockCustomer.add(new CustomerEntity(201, "john"));
		mockCustomer.add(new CustomerEntity(202, "joy"));

		Mockito.when(customerJpaDao.findAll()).thenReturn(mockCustomer);
		assertEquals(2, customerService.viewCustomers().size());
	}

	@Test // Get all customers exception test
	public void testGetAllCustomersException() {

		List<CustomerEntity> mockCustomers = new ArrayList<>();

		Mockito.when(customerJpaDao.findAll()).thenReturn(mockCustomers);
		Exception exception = assertThrows(CustomerNotFoundException.class, () -> customerService.viewCustomers());
		assertEquals("No customers found!!", exception.getMessage());
	}

	@Test // Customer insertion test
	public void testAddCustomer() {

		CustomerEntity mockReturnCustomer = new CustomerEntity(1, "ram");
		CustomerEntity mockArgumentCustomer = new CustomerEntity("ram");

		Mockito.when(customerJpaDao.save(mockArgumentCustomer)).thenReturn(mockReturnCustomer);
		assertEquals(1, customerService.insertCustomer(mockArgumentCustomer).getCustomerId());
	}

	@Test // Customer updation test
	public void testUpdateCustomer() {

		CustomerEntity mockReturnCustomer = new CustomerEntity(1, "ram");
		CustomerEntity mockArgumentCustomer = new CustomerEntity(1, "ramkumar");

		Mockito.when(customerJpaDao.save(mockArgumentCustomer)).thenReturn(mockReturnCustomer);
		customerService.updateCustomer(mockArgumentCustomer);
		Mockito.verify(customerJpaDao, Mockito.times(1)).save(mockArgumentCustomer);

	}

	@Test // Customer deletion test
	public void testDeleteCustomer() {

		int id = 10;
		CustomerEntity customer = new CustomerEntity();
		if (customer.getCustomerId() == id) {

			Mockito.doNothing().when(customerJpaDao).deleteById(id);
			customerService.deleteCustomer(id);
			Mockito.verify(customerJpaDao, Mockito.times(1)).deleteById(id);
		}
	}

	@Test // Fetch one customer test
	public void testViewCustomer() {

		CustomerEntity customer = new CustomerEntity();
		CustomerEntity mockReturnCustomer = new CustomerEntity(1);
		int mockArgumentCustomer = 1;
		if (customer.getCustomerId() == 1) {

			Mockito.when(customerJpaDao.save(customer)).thenReturn(mockReturnCustomer);
			customerService.viewCustomer(mockArgumentCustomer);
			Mockito.verify(customerJpaDao, Mockito.times(1)).save(customer);

		}
	}

}
