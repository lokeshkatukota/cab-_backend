package com.cabbooking;

import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import com.cabbooking.entities.TripBookingEntity;
import com.cabbooking.jpadao.ITripBookingJpaDao;
import com.cabbooking.service.ITripBookingService;
import com.cabbooking.service.TripBookingServiceImpl;

@SpringBootTest
public class TripBookingServiceTest {

	@InjectMocks
	ITripBookingService tripBookingService = new TripBookingServiceImpl();

	@Mock
	ITripBookingJpaDao tripBookingJpaDao;

	@Test // Get all trip bookings test
	public void testGetAllTripBooking() {

		List<TripBookingEntity> mockTrips = new ArrayList<>();
		mockTrips.add(new TripBookingEntity(1001, "Bangalore", "Chennai"));
		mockTrips.add(new TripBookingEntity(1002, "Pune", "Delhi"));

		Mockito.when(tripBookingJpaDao.findAll()).thenReturn(mockTrips);
		assertEquals(2, tripBookingService.viewAllTripBooking().size());
	}

	@Test // Trip booking insertion test
	public void testAddTripBooking() {

		TripBookingEntity mockReturnTrips = new TripBookingEntity(1, "Bangalore", "Hyderabad");
		TripBookingEntity mockArgumentTrips = new TripBookingEntity("Bangalore", "Hyderabad");

		Mockito.when(tripBookingJpaDao.save(mockArgumentTrips)).thenReturn(mockReturnTrips);
		assertEquals(1, tripBookingService.insertTripBooking(mockArgumentTrips).getTripBookingId());
	}

	@Test // Trip booking updation test
	public void testUpdateTripBooking() {

		TripBookingEntity mockReturnTrips = new TripBookingEntity(800, "Hyderabad");
		TripBookingEntity mockArgumentTrips = new TripBookingEntity(800, "Pune");

		Mockito.when(tripBookingJpaDao.save(mockArgumentTrips)).thenReturn(mockReturnTrips);
		tripBookingService.updateTripBooking(mockArgumentTrips);
		Mockito.verify(tripBookingJpaDao, Mockito.times(1)).save(mockArgumentTrips);

	}

	@Test // Trip deletion test
	public void testDeleteTripBooking() {

		int id = 850;
		Mockito.doNothing().when(tripBookingJpaDao).deleteById(id);
		tripBookingService.deleteTripBooking(id);
		Mockito.verify(tripBookingJpaDao, Mockito.times(1)).deleteById(id);
	}

}
