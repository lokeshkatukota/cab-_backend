package com.cabbooking;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import com.cabbooking.entities.DriverEntity;
import com.cabbooking.exceptions.DriverNotFoundException;
import com.cabbooking.jpadao.IDriverJpaDao;
import com.cabbooking.service.DriverServiceImpl;
import com.cabbooking.service.IDriverService;

@SpringBootTest
public class DriverServiceTest {

	@InjectMocks
	IDriverService driverService = new DriverServiceImpl();

	@Mock
	IDriverJpaDao driverJpaDao;

	@Test // Get all drivers test
	public void testGetAllDriver() {

		List<DriverEntity> mockDriver = new ArrayList<>();
		mockDriver.add(new DriverEntity(501, "Raj"));
		mockDriver.add(new DriverEntity(502, "Jacob"));

		Mockito.when(driverJpaDao.findAll()).thenReturn(mockDriver);
		assertEquals(2, driverService.viewDrivers().size());
	}

	@Test // Get all drivers exception test
	public void testGetAllDriverException() {

		List<DriverEntity> mockDrivers = new ArrayList<>();

	    Mockito.when(driverJpaDao.findAll()).thenReturn(mockDrivers);
		Exception exception = assertThrows(DriverNotFoundException.class, () -> driverService.viewDrivers());
		assertEquals("No drivers found!!", exception.getMessage());
	}

	@Test // Driver insertion test
	public void testAddDriver() {

		DriverEntity mockReturnDriver = new DriverEntity(1, "Arjun");
		DriverEntity mockArgumentDriver = new DriverEntity("Arjun");

		Mockito.when(driverJpaDao.save(mockArgumentDriver)).thenReturn(mockReturnDriver);
		assertEquals(1, driverService.insertDriver(mockArgumentDriver).getDriverId());
	}

	@Test // Driver updation test
	public void testUpdateDriver() {

		DriverEntity mockReturnDriver = new DriverEntity(1, "ram");
		DriverEntity mockArgumentDriver = new DriverEntity(1, "ramkumar");

		 Mockito.when(driverJpaDao.save(mockArgumentDriver)).thenReturn(mockReturnDriver);
		 driverService.updateDriver(mockArgumentDriver);
		 Mockito.verify(driverJpaDao, Mockito.times(1)).save(mockArgumentDriver);

	}

	@Test // Driver deletion test
	public void testDeleteDriver() {

		int id = 10;
		DriverEntity driver = new DriverEntity();
		if (driver.getDriverId() == id) {

		   Mockito.doNothing().when(driverJpaDao).deleteById(id);
		   driverService.deleteDriver(id);
		   Mockito.verify(driverJpaDao, Mockito.times(1)).deleteById(id);
		}
	}

	@Test // Fetch one driver test
	public void testViewDriver() {

		DriverEntity driver = new DriverEntity();
		DriverEntity mockReturnDriver = new DriverEntity(1);
		int mockArgumentDriver = 1;
		if (driver.getDriverId() == 1) {

			Mockito.when(driverJpaDao.save(driver)).thenReturn(mockReturnDriver);
			driverService.viewDriver(mockArgumentDriver);
			Mockito.verify(driverJpaDao, Mockito.times(1)).save(driver);

		}
	}

}
