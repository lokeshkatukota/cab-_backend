package com.cabbooking;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import com.cabbooking.entities.CabEntity;
import com.cabbooking.exceptions.CabNotFoundException;
import com.cabbooking.jpadao.ICabJpaDao;
import com.cabbooking.service.CabServiceImpl;
import com.cabbooking.service.ICabService;

@SpringBootTest
public class CabServiceTest {

	@InjectMocks
	ICabService cabService = new CabServiceImpl();

	@Mock
	ICabJpaDao cabJpaDao;

	@Test //Get all cabs test
	public void testViewCabs() {

		List<CabEntity> mockCabs = new ArrayList<>();
		mockCabs.add(new CabEntity(100, "Innova"));
		mockCabs.add(new CabEntity(200, "Swift"));
		mockCabs.add(new CabEntity(300, "Suv"));
		mockCabs.add(new CabEntity(400, "Xuv"));

		Mockito.when(cabJpaDao.findAll()).thenReturn(mockCabs);
		assertEquals(4, cabService.viewCabs().size());
	}

	@Test //Get all cabs exception test
	public void testGetAllCabException() {

		List<CabEntity> mockCabs = new ArrayList<>();

		Mockito.when(cabJpaDao.findAll()).thenReturn(mockCabs);
		Exception exception = assertThrows(CabNotFoundException.class, () -> cabService.viewCabs());
		assertEquals("No cabs found!!", exception.getMessage());
	}

	@Test //Cab insertion test
	public void testInsertCab() {

		CabEntity mockReturnCab = new CabEntity(100, "BMW");
		CabEntity mockArgumentCab = new CabEntity("BMW");

		Mockito.when(cabJpaDao.save(mockArgumentCab)).thenReturn(mockReturnCab);
		assertEquals(100, cabService.insertCab(mockArgumentCab).getCabId());
	}

	@Test //Cab updation test
	public void testUpdateCab() {

		CabEntity mockReturnCab = new CabEntity(100, "suv");
		CabEntity mockArgumentCab = new CabEntity("suv");

		Mockito.when(cabJpaDao.save(mockArgumentCab)).thenReturn(mockReturnCab);
		cabService.updateCab(mockArgumentCab);
		Mockito.verify(cabJpaDao, Mockito.times(1)).save(mockArgumentCab);
	}

	@Test //Cab deletion test
	public void testDeleteCab() {

		int id = 100;
		CabEntity cab = new CabEntity();
		if (cab.getCabId() == id) {

			Mockito.doNothing().when(cabJpaDao).deleteById(id);
			cabService.deleteCab(id);
			Mockito.verify(cabJpaDao, Mockito.times(1)).deleteById(id);

		}
	}

}
